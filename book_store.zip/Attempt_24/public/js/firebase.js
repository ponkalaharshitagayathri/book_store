var fireBase = fireBase || firebase;
var hasInit = false;
var config = {
  apiKey: "AIzaSyAYBcQYP5WQZ5Z889PQRs2Uw8_TQB99HL8",
  authDomain: "attempt3-817a6.firebaseapp.com",
  projectId: "attempt3-817a6",
  storageBucket: "attempt3-817a6.appspot.com",
  messagingSenderId: "913964319899",
  appId: "1:913964319899:web:7fa450362c22886d19323e",
  measurementId: "${config.measurementId}"
  };
if(!hasInit){
    firebase.initializeApp(config);
    hasInit = true;
}


